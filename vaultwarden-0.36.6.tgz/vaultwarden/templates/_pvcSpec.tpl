{{- define "vaultwarden.pvcSpec" }}
{{- if or .Values.storage.data .Values.storage.attachments -}}
volumeClaimTemplates:
  {{- with .Values.storage.data }}
  - metadata:
      name: {{ include "vaultwarden.fullname" $ }}-{{ .name }}
      labels:
        app.kubernetes.io/component: vaultwarden
        {{- include "vaultwarden.labels" $ | nindent 8 }}
      annotations:
        meta.helm.sh/release-name: {{ $.Release.Name | quote }}
        meta.helm.sh/release-namespace: {{ $.Release.Namespace | quote }}
        {{- if .keepPvc }}
        helm.sh/resource-policy: keep
        {{- end }}
    spec:
      accessModes:
        - {{ .accessMode | default "ReadWriteOnce" | quote }}
      resources:
        requests:
          storage: {{ .size }}
      {{- with .class }}
      storageClassName: {{ . | quote }}
      {{- end }}
  {{- end }}
  {{- with .Values.storage.attachments }}
  - metadata:
      name: {{ include "vaultwarden.fullname" $ }}-{{ .name }}
      labels:
        app.kubernetes.io/component: vaultwarden
        {{- include "vaultwarden.labels" $ | nindent 8 }}
      annotations:
        meta.helm.sh/release-name: {{ $.Release.Name | quote }}
        meta.helm.sh/release-namespace: {{ $.Release.Namespace | quote }}
        {{- if .keepPvc }}
        helm.sh/resource-policy: keep
        {{- end }}
    spec:
      accessModes:
        - {{ .accessMode | default "ReadWriteOnce" | quote }}
      resources:
        requests:
          storage: {{ .size }}
      {{- with .class }}
      storageClassName: {{ . | quote }}
      {{- end }}
  {{- end }}
{{- end }}
{{- end }}
